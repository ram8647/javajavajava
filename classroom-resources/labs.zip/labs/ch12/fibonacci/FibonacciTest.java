public class FibonacciTest
{
	public static void main(String argv[])
	{
		System.out.println("fib of 4 = " + Fibonacci.fibIter1(4));
	}
}
