public final class Days   // FINAL CLASS CAN'T BE EXTENDED
{
  
  private Days() { }     // PRIVATE CONSTRUCTOR SO CAN'T BE INSTANTIATED


} // Days


