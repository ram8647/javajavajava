//<!--
var docHdg="";
  docHdg += "<TABLE><TR>"
  docHdg += "<TD>"
  docHdg += "<IMG ALIGN=ABSMIDDLE SRC='../../html/cover3E.jpg' ALT='Java Java Java' ALIGN=left WIDTH=200 HEIGHT=280>"
  docHdg += "</TD>"
  docHdg += "<FONT COLOR=BLUE>"
  docHdg += "<TD><CENTER><H1>A Java, Java, Java, 3E <BR> Laboratory Project</H1>"
  docHdg += "<H4>[ <A HREF='../../index.html'>Lab Index</A>]</H4><br>";
  docHdg += "<H4> &#169; 2006 Prentice-Hall</H4></CENTER>";
  docHdg += "</TD></TR>"
  docHdg += "</TABLE>"
  docHdg += "<HR>";
  docHdg += "</FONT>"
  document.open();
  document.write(unescape(docHdg));
//-->
