//<!--
var docFtg="";
  docFtg += "<CENTER>";
  docFtg += "<HR ALIGN=center>";
  docFtg += "<b>Questions or Suggestions: </B>";
  docFtg += "<a href='mailto:ralph.morelli@trincoll.edu'><i>ralph.morelli@trincoll.edu</i></a>";
  docFtg += "</CENTER>";
  document.open();
  document.write(unescape(docFtg));

//-->
