/*
 * File: ShowDown.java
 * Author: Java, Java, Java
 * Description: A game of 1 card show down.
 * To compile: javac -classpath nplayer.jar:deck.jar:. Showdown.java
 * To run: java -classpath nplayer.jar:deck.jar:. Showdown
 */
