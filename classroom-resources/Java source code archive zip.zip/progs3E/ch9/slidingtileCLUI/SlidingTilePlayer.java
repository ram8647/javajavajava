public class SlidingTilePlayer extends Player implements IPlayer {   
    public String makeAMove(String prompt)  { return "";  }
    public String toString() {
            return "You, the user, are the player.";
    }
} // SlidingTilePlayer

