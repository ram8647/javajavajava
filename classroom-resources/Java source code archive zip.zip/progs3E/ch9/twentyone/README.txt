/*
 * File: TwentyOne.java
 * Author: Java, Java, Java
 * Description: A game of TwentyOne
 * To compile: javac -classpath nplayer.jar:deck.jar:. TwentyOne.java
 * To run: java -classpath nplayer.jar:deck.jar:. TwentyOne
 */
