public interface IPlayer {
    public String makeAMove(String prompt);
}
