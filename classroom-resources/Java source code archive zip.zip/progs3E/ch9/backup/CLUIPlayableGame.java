public interface CLUIPlayableGame extends IGame {
    public abstract void play(UserInterface ui);
}



