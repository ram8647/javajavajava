public interface IGame {
    public String getGamePrompt();
    public String reportGameState();
} //IGame

