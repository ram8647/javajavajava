public interface Playable {
    public abstract void play(UserInterface ui);
    public String prompt();
    public String reportState();
} ///Playable

