public interface PlayableGame extends Playable, IPlayer {}
