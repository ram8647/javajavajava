
import javax.swing.JFrame;
public interface Playable {

    public abstract void play(KeyboardReader kb);
    public abstract void play(GameGUI gui);
} ///Playable
