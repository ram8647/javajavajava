import javax.swing.JFrame;
public interface Playable {
    public abstract void play(UserInterface ui);
    public abstract void play(GameGUI gui);
    //    public abstract String report();
    //    public abstract String prompt();
} ///Playable

