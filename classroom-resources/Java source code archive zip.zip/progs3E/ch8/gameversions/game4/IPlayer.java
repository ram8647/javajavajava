public interface IPlayer {
    public String move(String prompt);
}
