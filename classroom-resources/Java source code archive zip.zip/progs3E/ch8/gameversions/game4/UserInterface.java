public interface UserInterface {
    public String getUserInput();
    public void report(String s);
    public void prompt(String s);
}
