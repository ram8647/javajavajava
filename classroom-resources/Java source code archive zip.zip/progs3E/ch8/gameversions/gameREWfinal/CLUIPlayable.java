public interface CLUIPlayable {
    public String prompt();
    public String reportState();
    public String move(String str);
} //CLUIPlayable

