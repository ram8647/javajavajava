public interface ComputerPlayable {

    /** The implementing class makes a move in an object
    implementing TwoPlayerGame and returns a string describing
    the move.
    */
    public String computerMove();

} //ComputerPlayable

