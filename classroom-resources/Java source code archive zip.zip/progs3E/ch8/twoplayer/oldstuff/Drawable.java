public interface Drawable {
    public void draw(java.awt.Graphics g);
}
