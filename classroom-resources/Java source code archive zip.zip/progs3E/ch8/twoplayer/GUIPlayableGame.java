public interface GUIPlayableGame extends IGame {
    public String submitUserMove(String theMove);
}
