/*
 * RockPaperScissors.java
 * The Rock Paper Scissors game.
 * To compile: javac -classpath twoplayer.jar:. RockPaperScissors.java
 * To run CLUI: java -classpath twoplayer.jar:. RockPaperScissors
 */
