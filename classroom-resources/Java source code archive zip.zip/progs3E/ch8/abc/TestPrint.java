public class TestPrint {
    public String toString() { return "Hello from TestPrint"; }
    public static void main(String args[]) {
        System.out.println(new Double(56));
        System.out.println(new TestPrint());
    }
}
