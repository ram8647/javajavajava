/*
 * OneRowNim.java
 * The full version of One Row Nim. This version can be CLUIPlayable or GUIPlayable
 * To compile: javac -classpath twoplayer.jar:.  OneRowNim.java
 * To run CLUI:  java -classpath twoplayer.jar:. OneRowNim
 */
