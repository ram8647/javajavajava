import javax.swing.*;

public class TemperatureJApplet extends JApplet
{   public void init()
    {   getContentPane().add(new TemperatureJPanel());
    } // init()
} // TemperatureJApplet class