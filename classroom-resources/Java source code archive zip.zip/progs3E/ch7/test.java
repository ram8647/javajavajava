public class test {

    String pi = new String(Math.PI+"");
}
