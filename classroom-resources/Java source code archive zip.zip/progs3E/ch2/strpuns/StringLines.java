public class StringLines {

    public static void main(String args[]) {
        String s = new String("string ");
        String s1 = new String("you ");
        String s2 = new String("pearls ");
        String s3 = new String("lights ");
        String s4 = "bean ";
        String s5 = "along ";
        String s6 = "out ";
        String s7 = "line ";
        String s8 = "cheese ";
        String s9 = "beans ";
        String s10 = "world ";
        String s11 = "heart ";
        String s12 = "lines ";
        String s13 = "quartet ";
     
        System.out.println("And the top 10 " + s + s12 + " are ...");
        System.out.println("10. Hey baby, wanna " + s + s5 + "with me!");
        System.out.println("9. You have more class than a " + s + "of " + s2 + ".");
        System.out.println("8. I've got the " + s10 + " on a " + s + ".");
        System.out.println("7. Would I " + s + s1 + s5 + "?");
        System.out.println("6. You melt my heart like " + s + s8 + ".");
        System.out.println("5. I'm the main " + s + s4 + "around here baby!");
        System.out.println("4. I will " + s + s3 + "on the town for you my love.");
        System.out.println("3. You make my " + s11 + s + "s sing.");
        System.out.println("2. Please don't " + s + " me " + s6 + ".");
        System.out.println("1. The music of our love is like a" + s + s13 + ".");
    }
}
