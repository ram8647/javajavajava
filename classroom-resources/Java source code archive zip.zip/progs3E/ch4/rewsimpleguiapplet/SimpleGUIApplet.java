    import javax.swing.*;

public class SimpleGUIApplet extends JApplet {
    public void init() {
          new SimpleGUI("Greeter");
    }
}



