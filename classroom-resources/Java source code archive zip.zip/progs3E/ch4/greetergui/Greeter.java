public class Greeter {

    public String greet(String name) {
        return "Hi " + name + " nice to meet you.";
    }
}
